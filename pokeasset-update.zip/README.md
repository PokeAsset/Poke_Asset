# PokéAsset

Pokémon card portfolio tracker (Collectr-style), built with Expo + React Native + TypeScript so it can ship to the iOS App Store.

## Run it

```bash
npm install
npx expo start        # press i for iOS simulator, or scan the QR with Expo Go
```

## What's in here

| Area | File |
| --- | --- |
| Navigation, tab bar | `App.tsx` |
| Slide-in menu (Catalog / My portfolio / Community / Business) | `src/MenuDrawer.tsx` |
| Colours, radii | `src/theme.ts` |
| Shared UI (header, gradient titles, chips, photo slots) | `src/ui.tsx` |
| Catalog + pricing (pokemontcg.io, TCGplayer market estimates) | `src/api.ts` |
| Local storage + price refresh (collection, wishlist, alerts, history) | `src/store.tsx` |
| Portfolio maths, value chart, entry form | `src/portfolio.ts`, `src/charts.tsx`, `src/EntryForm.tsx` |
| Price source (swap point for Poke Wallet) | `src/prices.ts` |
| Home, Assistant, Scan, Sealed scan, PokéGrade, Price research, Trade analyzer, Marketplace, My cards, Alerts | `src/screens/` |

## Honest status

Working with real data: portfolio value, cost and profit/loss, daily value history, set completion, wishlist with targets, price refresh, catalog search, "most valuable" grids, price research, card detail, add to collection, price alerts (only fire on a stored price), trade analyzer, local marketplace listings, photo capture.

Needs a backend before it is real:
- **Assistant**: `answer()` in `Assistant.tsx` is a local stub.
- **Card scan / Sealed scan / PokéGrade**: photos are captured, but recognition and grading need an image model behind an API.
- **Marketplace, Messages, accounts, payments**: listings are on-device only.
- **Menu pages with no screenshot** (Sets & checklists, Sealed products, Sealed market, Messages, My sale staging, Live shop, Store, My orders, Business pages): placeholder screens.

## Before the App Store

- Change `ios.bundleIdentifier` in `app.json`.
- Add `icon` and `splash` assets.
- Build with EAS: `npx eas build -p ios`.
- Pricing data comes from pokemontcg.io; check its terms and add your own backend/keys for production.
