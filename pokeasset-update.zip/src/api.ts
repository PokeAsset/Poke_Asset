import { Card } from './types';

const BASE = 'https://api.pokemontcg.io/v2/cards';

const PRICE_KEYS = [
  'holofoil',
  'normal',
  'reverseHolofoil',
  '1stEditionHolofoil',
  '1stEditionNormal',
  'unlimitedHolofoil',
];

const VARIANT_LABELS: Record<string, string> = {
  holofoil: 'Holofoil',
  normal: 'Normal',
  reverseHolofoil: 'Reverse holofoil',
  '1stEditionHolofoil': '1st edition holofoil',
  '1stEditionNormal': '1st edition normal',
  unlimitedHolofoil: 'Unlimited holofoil',
};

export type PriceDetail = {
  market: number | null;
  low: number | null;
  high: number | null;
  variant: string | null;
  updatedAt?: string;
};

/** Stored TCGplayer reading for a card (never rounded, never blended). */
export function priceDetail(card: Card): PriceDetail {
  const prices = card.tcgplayer?.prices;
  const updatedAt = card.tcgplayer?.updatedAt;
  if (prices) {
    for (const k of PRICE_KEYS) {
      const p = prices[k];
      if (p && typeof p.market === 'number') {
        return {
          market: p.market,
          low: typeof p.low === 'number' ? p.low : null,
          high: typeof p.high === 'number' ? p.high : null,
          variant: VARIANT_LABELS[k] ?? k,
          updatedAt,
        };
      }
    }
  }
  return { market: null, low: null, high: null, variant: null, updatedAt };
}

export function marketPrice(card: Card): number | null {
  return priceDetail(card).market;
}

export function formatMoney(n: number | null | undefined): string {
  if (n == null || isNaN(n)) return '—';
  return `$${n.toFixed(2)}`;
}

export function formatSigned(n: number | null | undefined): string {
  if (n == null || isNaN(n)) return '—';
  return `${n >= 0 ? '+' : '-'}$${Math.abs(n).toFixed(2)}`;
}

export function formatPct(n: number | null | undefined): string {
  if (n == null || isNaN(n)) return '—';
  return `${n >= 0 ? '+' : ''}${n.toFixed(1)}%`;
}

export function formatDate(s?: string | null): string {
  if (!s) return 'no date';
  const d = new Date(s.replace(/\//g, '-'));
  if (isNaN(d.getTime())) return s;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

async function query(q: string, pageSize = 24, orderBy?: string): Promise<Card[]> {
  const url =
    `${BASE}?q=${encodeURIComponent(q)}&pageSize=${pageSize}` +
    (orderBy ? `&orderBy=${encodeURIComponent(orderBy)}` : '') +
    '&select=id,name,number,rarity,set,images,tcgplayer';
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Catalog request failed (${res.status})`);
  const json = await res.json();
  return json.data as Card[];
}

export async function searchCards(text: string): Promise<Card[]> {
  const t = text.trim();
  if (!t) return [];
  const safe = t.replace(/"/g, '');
  const numeric = /^\d+$/.test(safe);
  const q = numeric ? `number:${safe}` : `name:"${safe}*" OR set.name:"${safe}*"`;
  return query(q, 24);
}

/** Fetch the latest copy of specific cards by their catalog ids. */
export async function fetchCardsByIds(ids: string[]): Promise<Card[]> {
  const unique = Array.from(new Set(ids));
  const out: Card[] = [];
  for (let i = 0; i < unique.length; i += 20) {
    const chunk = unique.slice(i, i + 20);
    const q = chunk.map((id) => `id:"${id}"`).join(' OR ');
    const part = await query(q, 250);
    out.push(...part);
  }
  return out;
}

/** Cards with the highest stored raw market estimates. */
export async function topCards(era?: string, rarity?: string, size = 24): Promise<Card[]> {
  const parts = ['tcgplayer.prices.holofoil.market:[80 TO *]'];
  if (era) parts.push(`set.series:"${era}"`);
  if (rarity) parts.push(`rarity:"${rarity}"`);
  const cards = await query(parts.join(' '), 250);
  return cards.sort((a, b) => (marketPrice(b) ?? 0) - (marketPrice(a) ?? 0)).slice(0, size);
}

const SEED: { name: string; number: string }[] = [
  { name: 'Latias & Latios-GX', number: '170' },
  { name: 'Umbreon VMAX', number: '215' },
  { name: 'Gengar & Mimikyu-GX', number: '165' },
  { name: 'Lucky Stadium', number: '' },
  { name: 'Lugia-EX', number: '' },
  { name: 'Rayquaza VMAX', number: '218' },
];

/** Home screen "Most valuable in the catalog" grid. */
export async function featuredCards(): Promise<Card[]> {
  const out = await Promise.all(
    SEED.map(async (s) => {
      const q = s.number ? `name:"${s.name}" number:${s.number}` : `name:"${s.name}"`;
      const r = await query(q, 20).catch(() => [] as Card[]);
      return r.sort((a, b) => (marketPrice(b) ?? 0) - (marketPrice(a) ?? 0))[0];
    }),
  );
  return out.filter(Boolean) as Card[];
}
