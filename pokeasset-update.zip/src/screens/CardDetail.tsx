import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, mono, radius } from '../theme';
import { Btn, Panel, Screen, PageHead } from '../ui';
import EntryForm from '../EntryForm';
import { Card } from '../types';
import { formatDate, formatMoney, marketPrice, priceDetail } from '../api';
import { useStore } from '../store';

export function CardTile({ card, onPress }: { card: Card; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ width: '31.5%' }}>
      <Image source={{ uri: card.images.small }} style={{ aspectRatio: 0.716, borderRadius: 10 }} />
    </Pressable>
  );
}

export function CardRow({
  card,
  index,
  onPress,
  right,
}: {
  card: Card;
  index?: number;
  onPress?: () => void;
  right?: React.ReactNode;
}) {
  return (
    <Pressable onPress={onPress} style={r.row}>
      {index != null ? <Text style={r.idx}>{index}</Text> : null}
      <Image source={{ uri: card.images.small }} style={r.img} />
      <View style={{ flex: 1 }}>
        <Text style={r.name} numberOfLines={1}>
          {card.name}
        </Text>
        <Text style={r.sub} numberOfLines={1}>
          {card.set.name} · #{card.number}
          {card.tcgplayer?.updatedAt ? ` · updated ${formatDate(card.tcgplayer.updatedAt)}` : ''}
        </Text>
      </View>
      <Text style={r.price}>{formatMoney(marketPrice(card))}</Text>
      {right}
    </Pressable>
  );
}

export default function CardDetail({ route }: any) {
  const card: Card = route.params.card;
  const { owned, wishlist, alerts, addOwned, addWishlist, removeWishlist, addAlert, removeAlert } = useStore();
  const d = priceDetail(card);
  const [target, setTarget] = useState('');
  const [adding, setAdding] = useState(false);
  const [notice, setNotice] = useState('');
  const [alertErr, setAlertErr] = useState('');

  const copies = owned.filter((e) => e.card.id === card.id).reduce((n, e) => n + e.qty, 0);
  const wished = wishlist.find((w) => w.card.id === card.id);
  const myAlerts = alerts.filter((a) => a.card.id === card.id);

  const setAlert = (dir: 'below' | 'above') => {
    const n = Number(target);
    if (target.trim() === '' || isNaN(n) || n <= 0) return setAlertErr('Enter a target price like 25.00.');
    setAlertErr('');
    addAlert(card, n, dir);
    setTarget('');
    setNotice(`Alert set: ${dir} ${formatMoney(n)}.`);
  };

  return (
    <Screen>
      <PageHead eyebrow={`${card.set.name} · #${card.number}`} title={card.name} />
      <Image
        source={{ uri: card.images.large }}
        style={{ width: '100%', aspectRatio: 0.716, borderRadius: 16 }}
        resizeMode="contain"
      />
      <Panel>
        <Text style={r.label}>STORED MARKET ESTIMATE</Text>
        <Text style={r.big}>{formatMoney(d.market)}</Text>
        {d.market != null ? (
          <Text style={r.sub}>
            Low {formatMoney(d.low)} · High {formatMoney(d.high)} · {d.variant}
          </Text>
        ) : null}
        <Text style={[r.sub, { marginTop: 8 }]}>
          {d.market == null
            ? 'No stored price for this card — alerts stay unverified.'
            : `TCGplayer via pokemontcg.io · ${formatDate(d.updatedAt)}. An estimate is not a sale.`}
        </Text>
      </Panel>

      {notice ? <Text style={{ color: colors.amber }}>{notice}</Text> : null}

      <Panel style={{ gap: 12 }}>
        <Text style={r.label}>YOUR COPIES · {copies}</Text>
        {adding ? (
          <EntryForm
            submitLabel="Add to my cards"
            onCancel={() => setAdding(false)}
            onSubmit={(v) => {
              addOwned({ card, ...v });
              setAdding(false);
              setNotice(`${card.name} is in your collection.`);
            }}
          />
        ) : (
          <Btn kind="gold" label="Add to collection" icon="add" onPress={() => setAdding(true)} />
        )}
      </Panel>

      <Panel style={{ gap: 12 }}>
        <Text style={r.label}>WISHLIST</Text>
        {wished ? (
          <Btn label="Remove from wishlist" icon="heart" onPress={() => removeWishlist(wished.key)} />
        ) : (
          <Btn label="Add to wishlist" icon="heart-outline" onPress={() => addWishlist(card)} />
        )}
      </Panel>

      <Panel style={{ gap: 12 }}>
        <Text style={r.label}>PRICE ALERT</Text>
        <TextInput
          value={target}
          onChangeText={setTarget}
          keyboardType="decimal-pad"
          placeholder="Target price ($)"
          placeholderTextColor={colors.muted}
          style={r.input}
        />
        {alertErr ? <Text style={{ color: colors.red }}>{alertErr}</Text> : null}
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn label="Alert if below" onPress={() => setAlert('below')} />
          <Btn label="Alert if above" onPress={() => setAlert('above')} />
        </View>
        {myAlerts.map((a) => (
          <View key={a.key} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ color: colors.text }}>
              {a.direction} {formatMoney(a.target)}
            </Text>
            <Pressable onPress={() => removeAlert(a.key)}>
              <Text style={{ color: colors.muted }}>Remove</Text>
            </Pressable>
          </View>
        ))}
      </Panel>
    </Screen>
  );
}

const r = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  idx: { color: colors.muted, width: 18, fontSize: 16 },
  img: { width: 56, height: 78, borderRadius: 6 },
  name: { color: colors.text, fontSize: 19, fontWeight: '500' },
  sub: { color: colors.muted, fontSize: 14, fontFamily: mono, marginTop: 4 },
  price: { color: colors.text, fontFamily: mono, fontWeight: '700', fontSize: 16 },
  label: { color: colors.muted, fontSize: 13, letterSpacing: 3, fontWeight: '700' },
  big: { color: colors.text, fontSize: 36, fontFamily: mono, fontWeight: '700', marginVertical: 8 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: 18,
    paddingVertical: 14,
    color: colors.text,
    fontSize: 16,
  },
});
