import React from 'react';
import { Text, View } from 'react-native';
import { colors, mono } from './theme';
import { formatMoney } from './api';
import { Snapshot } from './types';

/**
 * Portfolio value over time. Only real, recorded readings are drawn: one per
 * day the app refreshed prices. No back-filled or invented history.
 */
export function ValueChart({ snapshots }: { snapshots: Snapshot[] }) {
  const pts = snapshots.slice(-30);
  if (pts.length < 2) {
    return (
      <Text style={{ color: colors.muted, fontSize: 15, lineHeight: 22 }}>
        History builds up as you open the app on different days. Today's value is saved; come back
        tomorrow to see the first change.
      </Text>
    );
  }
  const max = Math.max(...pts.map((p) => p.value), 1);
  const first = pts[0];
  const last = pts[pts.length - 1];
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, gap: 3 }}>
        {pts.map((p) => (
          <View
            key={p.date}
            style={{
              flex: 1,
              height: Math.max(4, (p.value / max) * 120),
              backgroundColor: p.value >= first.value ? colors.amber : colors.red,
              borderRadius: 3,
            }}
          />
        ))}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {first.date} · {formatMoney(first.value)}
        </Text>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {last.date} · {formatMoney(last.value)}
        </Text>
      </View>
    </View>
  );
}
