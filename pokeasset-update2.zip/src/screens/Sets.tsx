import React, { useEffect, useMemo, useState } from 'react';
import { Image, Pressable, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme';
import { Empty, Loading, PageHead, Panel, Screen, SearchBox, Segmented } from '../ui';
import { fetchSetCards, fetchSets, formatMoney, marketPrice, SetInfo } from '../api';
import { Card } from '../types';
import { useStore } from '../store';
import { CardRow } from './CardDetail';

/** Every Pokémon TCG set in the catalog, grouped by series. */
export default function Sets() {
  const nav = useNavigation<any>();
  const { owned } = useStore();
  const [sets, setSets] = useState<SetInfo[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');

  useEffect(() => {
    fetchSets()
      .then(setSets)
      .catch((e) => setError(e?.message ?? 'Could not load sets.'))
      .finally(() => setBusy(false));
  }, []);

  const ownedBySet = useMemo(() => {
    const m = new Map<string, Set<string>>();
    owned.forEach((e) => {
      const s = m.get(e.card.set.id) ?? new Set<string>();
      s.add(e.card.id);
      m.set(e.card.set.id, s);
    });
    return m;
  }, [owned]);

  const shown = sets.filter(
    (s) => !q.trim() || s.name.toLowerCase().includes(q.trim().toLowerCase()) || s.series.toLowerCase().includes(q.trim().toLowerCase()),
  );
  const groups = useMemo(() => {
    const g = new Map<string, SetInfo[]>();
    shown.forEach((s) => g.set(s.series, [...(g.get(s.series) ?? []), s]));
    return Array.from(g.entries());
  }, [shown]);

  return (
    <Screen>
      <PageHead
        eyebrow="Catalog"
        title="Sets & checklists"
        text={`Every set in the catalog${sets.length ? ` (${sets.length})` : ''}. Open a set to see all of its cards and prices, and what you own.`}
      />
      <SearchBox value={q} onChangeText={setQ} placeholder="Search a set or era" />
      {busy ? <Loading /> : null}
      {error ? <Text style={{ color: colors.red }}>{error}</Text> : null}
      {groups.map(([series, list]) => (
        <Panel key={series} style={{ gap: 4 }}>
          <Text style={{ color: colors.muted, letterSpacing: 3, fontWeight: '700', fontSize: 13, marginBottom: 6 }}>
            {series.toUpperCase()}
          </Text>
          {list.map((s) => {
            const have = ownedBySet.get(s.id)?.size ?? 0;
            return (
              <Pressable
                key={s.id}
                onPress={() => nav.navigate('SetDetail', { set: s })}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border }}
              >
                {s.images?.symbol ? <Image source={{ uri: s.images.symbol }} style={{ width: 28, height: 28 }} resizeMode="contain" /> : <View style={{ width: 28 }} />}
                <View style={{ flex: 1 }}>
                  <Text style={{ color: colors.text, fontSize: 17 }}>{s.name}</Text>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>
                    {s.total} cards · {s.releaseDate}
                  </Text>
                </View>
                {have > 0 ? (
                  <Text style={{ color: colors.amber, fontWeight: '700' }}>
                    {have}/{s.total}
                  </Text>
                ) : null}
              </Pressable>
            );
          })}
        </Panel>
      ))}
    </Screen>
  );
}

/** All cards of one set with prices, plus owned / missing filters. */
export function SetDetail({ route }: any) {
  const nav = useNavigation<any>();
  const set: SetInfo = route.params.set;
  const { owned } = useStore();
  const [cards, setCards] = useState<Card[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [seg, setSeg] = useState('All');
  const [q, setQ] = useState('');

  useEffect(() => {
    fetchSetCards(set.id)
      .then(setCards)
      .catch((e) => setError(e?.message ?? 'Could not load cards.'))
      .finally(() => setBusy(false));
  }, [set.id]);

  const have = useMemo(() => new Set(owned.map((e) => e.card.id)), [owned]);
  const shown = cards
    .filter((c) => seg === 'All' || (seg === 'Owned') === have.has(c.id))
    .filter((c) => !q.trim() || c.name.toLowerCase().includes(q.trim().toLowerCase()) || c.number === q.trim());
  const setValue = cards.reduce((n, c) => n + (marketPrice(c) ?? 0), 0);
  const ownedCount = cards.filter((c) => have.has(c.id)).length;

  return (
    <Screen>
      <PageHead eyebrow={`${set.series} · ${set.releaseDate}`} title={set.name} text={`${set.total} cards in the set.`} />
      {!busy && cards.length ? (
        <Panel style={{ gap: 4 }}>
          <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700' }}>
            You own {ownedCount} of {cards.length}
          </Text>
          <Text style={{ color: colors.muted }}>One of each card at stored market prices: {formatMoney(setValue)}</Text>
        </Panel>
      ) : null}
      <SearchBox value={q} onChangeText={setQ} placeholder="Search this set" />
      <Segmented options={['All', 'Owned', 'Missing']} value={seg} onChange={setSeg} />
      {busy ? <Loading /> : null}
      {error ? <Text style={{ color: colors.red }}>{error}</Text> : null}
      <Panel>
        {!busy && shown.length === 0 ? (
          <Empty icon="albums-outline" text="No cards match." />
        ) : (
          shown.map((c) => (
            <CardRow
              key={c.id}
              card={c}
              onPress={() => nav.navigate('CardDetail', { card: c })}
              right={have.has(c.id) ? <Text style={{ color: colors.amber, fontWeight: '700' }}>✓</Text> : null}
            />
          ))
        )}
      </Panel>
    </Screen>
  );
}
