import React, { useMemo, useState } from 'react';
import { Modal, Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors, mono, radius } from '../theme';
import { Btn, Empty, PageHead, Panel, Screen, SearchBox, Segmented, Select } from '../ui';
import { formatDate, formatMoney, formatPct, formatSigned } from '../api';
import { useStore } from '../store';
import { entryPnl, entryValue, portfolioTotals, setProgress } from '../portfolio';
import { ValueChart } from '../charts';
import EntryForm from '../EntryForm';
import { OwnedEntry } from '../types';
import { CardRow } from './CardDetail';

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: string }) {
  return (
    <Panel style={{ width: '48.5%', borderRadius: 24, minHeight: 130, padding: 18 }}>
      <Text style={{ color: colors.muted, letterSpacing: 2, fontWeight: '700', fontSize: 12 }}>{label}</Text>
      <Text
        style={{ color: tone ?? colors.text, fontSize: 28, fontFamily: mono, fontWeight: '800', marginTop: 10 }}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        {value}
      </Text>
      {sub ? <Text style={{ color: colors.muted, fontSize: 14, marginTop: 6 }}>{sub}</Text> : null}
    </Panel>
  );
}

const SORTS = ['Newest', 'Value (high to low)', 'Profit (high to low)', 'Name (A–Z)'];

export default function MyCards() {
  const nav = useNavigation<any>();
  const { owned, updateOwned, removeOwned, snapshots, refreshPrices, refreshing, refreshError, lastRefreshed } =
    useStore();
  const [q, setQ] = useState('');
  const [seg, setSeg] = useState('All');
  const [sort, setSort] = useState(SORTS[0]);
  const [editKey, setEditKey] = useState<string | null>(null);

  const totals = useMemo(() => portfolioTotals(owned), [owned]);
  const sets = useMemo(() => setProgress(owned), [owned]);
  const editing = owned.find((e) => e.key === editKey) ?? null;

  const shown = useMemo(() => {
    const list = owned
      .filter((e) => seg === 'All' || (seg === 'Graded') === e.graded)
      .filter((e) => !q.trim() || e.card.name.toLowerCase().includes(q.trim().toLowerCase()));
    const val = (e: OwnedEntry) => (entryValue(e).perCopy ?? -1) * e.qty;
    const pnl = (e: OwnedEntry) => entryPnl(e).pnl ?? -Infinity;
    if (sort === SORTS[1]) list.sort((a, b) => val(b) - val(a));
    else if (sort === SORTS[2]) list.sort((a, b) => pnl(b) - pnl(a));
    else if (sort === SORTS[3]) list.sort((a, b) => a.card.name.localeCompare(b.card.name));
    return list;
  }, [owned, seg, q, sort]);

  const tone = totals.pnl > 0 ? colors.amber : totals.pnl < 0 ? colors.red : colors.text;

  return (
    <Screen>
      <PageHead
        eyebrow="My collection"
        title="My cards"
        text="Every copy you have recorded, valued at the stored market price or your own value for graded cards."
      />
      <View style={{ flexDirection: 'row', gap: 12, flexWrap: 'wrap' }}>
        <Btn
          label={refreshing ? 'Refreshing…' : 'Refresh prices'}
          icon="refresh"
          disabled={refreshing}
          onPress={() => refreshPrices()}
        />
        <Btn kind="gold" label="Add cards" onPress={() => nav.navigate('CardDatabase')} />
      </View>
      <Text style={{ color: refreshError ? colors.red : colors.muted }}>
        {refreshError
          ? `Last refresh failed: ${refreshError}`
          : lastRefreshed
          ? `Prices last refreshed ${formatDate(lastRefreshed)}`
          : 'Prices have not been refreshed yet.'}
      </Text>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        <Stat label="PORTFOLIO VALUE" value={formatMoney(totals.value)} sub={totals.unpriced ? `${totals.unpriced} copies have no price` : 'market + your values'} />
        <Stat label="TOTAL COST" value={formatMoney(totals.cost)} />
        <Stat
          label="PROFIT / LOSS"
          value={totals.pricedCost > 0 ? formatSigned(totals.pnl) : '—'}
          sub={totals.pnlPct != null ? formatPct(totals.pnlPct) : 'needs a cost and a price'}
          tone={tone}
        />
        <Stat label="COPIES" value={String(totals.copies)} sub={`${totals.graded} graded`} />
      </View>

      <Panel style={{ gap: 12 }}>
        <Text style={{ color: colors.muted, letterSpacing: 3, fontWeight: '700', fontSize: 13 }}>VALUE HISTORY</Text>
        <ValueChart snapshots={snapshots} />
      </Panel>

      <SearchBox value={q} onChangeText={setQ} placeholder="Search your cards" />
      <Segmented options={['All', 'Raw', 'Graded']} value={seg} onChange={setSeg} />
      <Select value={sort} options={SORTS} onChange={setSort} />

      {shown.length === 0 ? (
        <Empty
          icon="albums-outline"
          text={owned.length === 0 ? 'Nothing here yet. Add cards from the catalog.' : 'No cards match this filter.'}
        />
      ) : (
        <Panel>
          {shown.map((e) => {
            const v = entryValue(e);
            const p = entryPnl(e);
            return (
              <View key={e.key} style={{ paddingBottom: 8 }}>
                <CardRow
                  card={e.card}
                  onPress={() => nav.navigate('CardDetail', { card: e.card })}
                  right={null}
                />
                <Pressable onPress={() => setEditKey(e.key)} style={{ gap: 4 }}>
                  <Text style={{ color: colors.text }}>
                    {e.qty} × {e.graded ? `${e.company ?? ''} ${e.grade ?? ''}`.trim() : e.condition ?? 'Raw'} · cost{' '}
                    {formatMoney(e.cost)} each
                  </Text>
                  <Text style={{ color: colors.muted }}>
                    Value {v.perCopy == null ? '—' : formatMoney(v.perCopy * e.qty)}
                    {v.basis === 'declared' ? ' (your value)' : ''}
                    {p.pnl != null ? ` · ${formatSigned(p.pnl)} (${formatPct(p.pct)})` : ''}
                  </Text>
                  <Text style={{ color: colors.amber }}>Edit</Text>
                </Pressable>
              </View>
            );
          })}
        </Panel>
      )}

      <Panel style={{ gap: 10 }}>
        <Text style={{ color: colors.muted, letterSpacing: 3, fontWeight: '700', fontSize: 13 }}>SET COMPLETION</Text>
        {sets.length === 0 ? (
          <Text style={{ color: colors.muted }}>Sets you collect from will show up here.</Text>
        ) : (
          sets.map((st) => {
            const pct = st.total ? Math.min(100, (st.owned / st.total) * 100) : 0;
            return (
              <View key={st.setId} style={{ gap: 6 }}>
                <Text style={{ color: colors.text }}>
                  {st.name} · {st.owned}
                  {st.total ? ` / ${st.total}` : ''}
                </Text>
                <View style={{ height: 8, borderRadius: 4, backgroundColor: colors.border }}>
                  <View style={{ height: 8, borderRadius: 4, width: `${pct}%`, backgroundColor: colors.amber }} />
                </View>
              </View>
            );
          })
        )}
      </Panel>

      <Modal transparent animationType="fade" visible={!!editing} onRequestClose={() => setEditKey(null)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 16 }}>
          <View
            style={{
              backgroundColor: colors.card,
              borderRadius: radius.md,
              borderWidth: 1,
              borderColor: colors.border,
              maxHeight: '90%',
            }}
          >
            <ScrollView contentContainerStyle={{ padding: 18, gap: 12 }} keyboardShouldPersistTaps="handled">
              {editing ? (
                <>
                  <Text style={{ color: colors.text, fontSize: 20, fontWeight: '700' }}>{editing.card.name}</Text>
                  <EntryForm
                    initial={editing}
                    submitLabel="Save changes"
                    onSubmit={(v) => {
                      updateOwned(editing.key, v);
                      setEditKey(null);
                    }}
                    onCancel={() => setEditKey(null)}
                    onDelete={() => {
                      removeOwned(editing.key);
                      setEditKey(null);
                    }}
                  />
                </>
              ) : null}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
