import { marketPrice } from './api';
import { OwnedEntry, Snapshot } from './types';

export type ValueBasis = 'declared' | 'market' | 'none';

/** Value of ONE copy: your own declared value wins, else the stored market estimate. */
export function entryValue(e: OwnedEntry): { perCopy: number | null; basis: ValueBasis } {
  if (typeof e.declaredValue === 'number' && e.declaredValue >= 0) {
    return { perCopy: e.declaredValue, basis: 'declared' };
  }
  const m = marketPrice(e.card);
  if (m != null) return { perCopy: m, basis: 'market' };
  return { perCopy: null, basis: 'none' };
}

export function entryPnl(e: OwnedEntry): { pnl: number | null; pct: number | null } {
  const v = entryValue(e);
  if (v.perCopy == null) return { pnl: null, pct: null };
  const cost = e.cost * e.qty;
  const pnl = v.perCopy * e.qty - cost;
  return { pnl, pct: cost > 0 ? (pnl / cost) * 100 : null };
}

export type Totals = {
  copies: number;
  graded: number;
  value: number;
  cost: number;
  pricedCost: number;
  pnl: number;
  pnlPct: number | null;
  unpriced: number;
};

/**
 * Profit/loss only compares value against the cost of copies that HAVE a price,
 * so a card with no price never shows up as a fake loss.
 */
export function portfolioTotals(owned: OwnedEntry[]): Totals {
  let copies = 0;
  let graded = 0;
  let value = 0;
  let cost = 0;
  let pricedCost = 0;
  let unpriced = 0;
  for (const e of owned) {
    copies += e.qty;
    if (e.graded) graded += e.qty;
    cost += e.cost * e.qty;
    const v = entryValue(e);
    if (v.perCopy == null) {
      unpriced += e.qty;
    } else {
      value += v.perCopy * e.qty;
      pricedCost += e.cost * e.qty;
    }
  }
  const pnl = value - pricedCost;
  return {
    copies,
    graded,
    value,
    cost,
    pricedCost,
    pnl,
    pnlPct: pricedCost > 0 ? (pnl / pricedCost) * 100 : null,
    unpriced,
  };
}

export type SetProgress = {
  setId: string;
  name: string;
  series?: string;
  owned: number;
  total: number | null;
};

/** Distinct cards owned per set, against the set's total card count. */
export function setProgress(owned: OwnedEntry[]): SetProgress[] {
  const map = new Map<string, { name: string; series?: string; total: number | null; ids: Set<string> }>();
  for (const e of owned) {
    const s = e.card.set;
    let row = map.get(s.id);
    if (!row) {
      row = { name: s.name, series: s.series, total: s.total ?? s.printedTotal ?? null, ids: new Set<string>() };
      map.set(s.id, row);
    }
    row.ids.add(e.card.id);
  }
  const list: SetProgress[] = [];
  map.forEach((row, setId) => {
    list.push({ setId, name: row.name, series: row.series, owned: row.ids.size, total: row.total });
  });
  list.sort((a, b) => {
    const pa = a.total ? a.owned / a.total : 0;
    const pb = b.total ? b.owned / b.total : 0;
    return pb - pa || a.name.localeCompare(b.name);
  });
  return list;
}

/** Local date as YYYY-MM-DD. */
export function todayKey(d: Date = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

/** One snapshot per day; a newer reading on the same day replaces the older one. */
export function upsertSnapshot(prev: Snapshot[], next: Snapshot): Snapshot[] {
  const rest = prev.filter((s) => s.date !== next.date);
  return [...rest, next].sort((a, b) => a.date.localeCompare(b.date)).slice(-365);
}
