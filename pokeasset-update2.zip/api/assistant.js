const { limited, send, readBody, gemini } = require('./_util');

const SYSTEM =
  'You are the PokéAsset assistant, a careful Pokémon card collecting and investing helper. ' +
  'Rules: never invent a price, sale or population number. Only quote prices that appear in the CONTEXT the app sends. ' +
  'If you do not have a price, say so and say where the user could check (TCGplayer, eBay sold listings, PSA). ' +
  'Distinguish an estimate, an asking price and a sold price. This is general information, not financial advice. ' +
  'Keep answers short and practical. Use plain text, no markdown tables.';

module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { error: 'POST only' });
  if (limited(req, 20)) return send(res, 429, { error: 'Too many requests. Wait a minute and try again.' });
  const body = await readBody(req);
  const msgs = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  const context = typeof body.context === 'string' ? body.context.slice(0, 6000) : '';
  if (msgs.length === 0) return send(res, 400, { error: 'No message.' });
  const transcript = msgs
    .map((m) => `${m.role === 'assistant' ? 'Assistant' : 'User'}: ${String(m.text || '').slice(0, 2000)}`)
    .join('\n');
  try {
    const text = await gemini({
      system: SYSTEM,
      parts: [{ text: `CONTEXT (from the user's app, may be empty):\n${context || '(none)'}\n\nCONVERSATION:\n${transcript}\n\nAssistant:` }],
    });
    return send(res, 200, { ok: true, text });
  } catch (e) {
    if (e.code === 'not_configured') return send(res, 503, { error: e.message, notConfigured: true });
    return send(res, 502, { error: e.message || 'Assistant request failed.' });
  }
};
