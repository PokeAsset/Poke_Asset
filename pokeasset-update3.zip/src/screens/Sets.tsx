import React, { useEffect, useMemo, useState } from 'react';
import { Image, Pressable, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors, radius } from '../theme';
import { Empty, Loading, PageHead, Panel, Screen, SearchBox, Segmented, Select } from '../ui';
import { fetchSetCards, fetchSets, formatDate, formatMoney, marketPrice, SetInfo } from '../api';
import { EraGroup, groupByEra } from '../eras';
import { searchSealed, SealedItem } from '../server';
import { Card } from '../types';
import { useStore } from '../store';
import { CardRow } from './CardDetail';

/** Small "+ Add" pill used on every card and sealed item. */
function AddButton({ count, onPress }: { count: number; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        borderWidth: 1,
        borderColor: count > 0 ? colors.tintGoldBorder : colors.border,
        backgroundColor: count > 0 ? colors.tintGold : colors.card,
        borderRadius: radius.pill,
        paddingHorizontal: 12,
        paddingVertical: 8,
      }}
    >
      <Text style={{ color: count > 0 ? colors.gold : colors.text, fontWeight: '700', fontSize: 13 }}>
        {count > 0 ? `+ Add (${count})` : '+ Add'}
      </Text>
    </Pressable>
  );
}

function useSets() {
  const [sets, setSets] = useState<SetInfo[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    fetchSets()
      .then(setSets)
      .catch((e) => setError(e?.message ?? 'Could not load sets.'))
      .finally(() => setBusy(false));
  }, []);
  return { sets, busy, error };
}

const years = (sets: SetInfo[]) => {
  const ys = sets.map((s) => s.releaseDate.slice(0, 4)).sort();
  return ys.length ? (ys[0] === ys[ys.length - 1] ? ys[0] : `${ys[0]}–${ys[ys.length - 1]}`) : '';
};

function SetTile({ set, onPress, have }: { set: SetInfo; onPress: () => void; have: number }) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        width: '48.5%',
        backgroundColor: colors.card,
        borderColor: colors.border,
        borderWidth: 1,
        borderRadius: radius.md,
        padding: 12,
        gap: 6,
        alignItems: 'center',
      }}
    >
      <View style={{ height: 56, width: '100%', alignItems: 'center', justifyContent: 'center' }}>
        {set.images?.logo ? (
          <Image source={{ uri: set.images.logo }} style={{ width: '90%', height: 56 }} resizeMode="contain" />
        ) : (
          <Text style={{ color: colors.text, fontWeight: '700' }}>{set.name}</Text>
        )}
      </View>
      <Text style={{ color: colors.text, fontSize: 15, fontWeight: '600', textAlign: 'center' }} numberOfLines={2}>
        {set.name}
      </Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        {set.images?.symbol ? <Image source={{ uri: set.images.symbol }} style={{ width: 18, height: 18 }} resizeMode="contain" /> : null}
        <Text style={{ color: colors.muted, fontSize: 12 }}>
          {formatDate(set.releaseDate)}
        </Text>
      </View>
      <Text style={{ color: have > 0 ? colors.amber : colors.muted, fontSize: 12 }}>
        {have > 0 ? `${have}/${set.total} owned` : `${set.total} cards`}
      </Text>
    </Pressable>
  );
}

function useOwnedBySet() {
  const { owned } = useStore();
  return useMemo(() => {
    const m = new Map<string, Set<string>>();
    owned.forEach((e) => {
      const s = m.get(e.card.set.id) ?? new Set<string>();
      s.add(e.card.id);
      m.set(e.card.set.id, s);
    });
    return m;
  }, [owned]);
}

/** Step 1: eras. Typing in the search box searches every set instead. */
export default function Sets() {
  const nav = useNavigation<any>();
  const { sets, busy, error } = useSets();
  const have = useOwnedBySet();
  const [q, setQ] = useState('');
  const eras = useMemo(() => groupByEra(sets), [sets]);
  const found = q.trim() ? sets.filter((s) => s.name.toLowerCase().includes(q.trim().toLowerCase())) : [];

  return (
    <Screen>
      <PageHead
        eyebrow="Browse"
        title="Sets & checklists"
        text={`Pick an era, then a set, to see every card and sealed product${sets.length ? ` (${sets.length} sets)` : ''}.`}
      />
      <SearchBox value={q} onChangeText={setQ} placeholder="Search a set by name" />
      {busy ? <Loading /> : null}
      {error ? <Text style={{ color: colors.red }}>{error}</Text> : null}
      {q.trim() ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {found.length === 0 && !busy ? <Empty icon="search-outline" text="No set has that name." /> : null}
          {found.map((s) => (
            <SetTile key={s.id} set={s} have={have.get(s.id)?.size ?? 0} onPress={() => nav.navigate('SetDetail', { set: s })} />
          ))}
        </View>
      ) : (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {eras.map((e) => (
            <Pressable
              key={e.id}
              onPress={() => nav.navigate('Era', { era: e })}
              style={{
                width: '48.5%',
                minHeight: 110,
                backgroundColor: colors.card,
                borderColor: colors.border,
                borderWidth: 1,
                borderRadius: radius.md,
                padding: 16,
                justifyContent: 'space-between',
              }}
            >
              <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700' }}>{e.name}</Text>
              <Text style={{ color: colors.muted, fontSize: 13 }}>
                {e.sets.length} sets · {years(e.sets)}
              </Text>
            </Pressable>
          ))}
        </View>
      )}
    </Screen>
  );
}

/** Step 2: every set in one era, as a grid of logos. */
export function EraSets({ route }: any) {
  const nav = useNavigation<any>();
  const era: EraGroup = route.params.era;
  const have = useOwnedBySet();
  return (
    <Screen>
      <PageHead eyebrow={`${era.sets.length} sets · ${years(era.sets)}`} title={era.name} text="Newest first. Tap a set to open its cards and sealed products." />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {era.sets.map((s) => (
          <SetTile key={s.id} set={s} have={have.get(s.id)?.size ?? 0} onPress={() => nav.navigate('SetDetail', { set: s })} />
        ))}
      </View>
    </Screen>
  );
}

/** Step 3: all cards of the set (by card number) or its sealed products. */
export function SetDetail({ route }: any) {
  const nav = useNavigation<any>();
  const set: SetInfo = route.params.set;
  const { owned, addOwned, sealed, addSealed } = useStore();
  const [tab, setTab] = useState('Singles');

  const [cards, setCards] = useState<Card[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [rarity, setRarity] = useState('All rarities');
  const [seg, setSeg] = useState('All');
  const [notice, setNotice] = useState('');

  const [items, setItems] = useState<SealedItem[] | null>(null);
  const [sBusy, setSBusy] = useState(false);
  const [sError, setSError] = useState('');

  useEffect(() => {
    fetchSetCards(set.id)
      .then(setCards)
      .catch((e) => setError(e?.message ?? 'Could not load cards.'))
      .finally(() => setBusy(false));
  }, [set.id]);

  useEffect(() => {
    if (tab !== 'Sealed' || items || sBusy) return;
    setSBusy(true);
    setSError('');
    (async () => {
      try {
        let list = await searchSealed('', set.name);
        if (list.length === 0) list = await searchSealed(set.name);
        setItems(list);
      } catch (e: any) {
        setSError(e?.message ?? 'Could not load sealed products.');
      } finally {
        setSBusy(false);
      }
    })();
  }, [tab]);

  const count = useMemo(() => {
    const m = new Map<string, number>();
    owned.forEach((e) => m.set(e.card.id, (m.get(e.card.id) ?? 0) + e.qty));
    return m;
  }, [owned]);

  const rarities = useMemo(
    () => ['All rarities', ...Array.from(new Set(cards.map((c) => c.rarity).filter((r): r is string => !!r))).sort()],
    [cards],
  );
  const shown = cards
    .filter((c) => rarity === 'All rarities' || c.rarity === rarity)
    .filter((c) => seg === 'All' || (seg === 'Owned') === (count.get(c.id) ?? 0) > 0)
    .filter((c) => !q.trim() || c.name.toLowerCase().includes(q.trim().toLowerCase()) || c.number === q.trim());
  const ownedDistinct = cards.filter((c) => (count.get(c.id) ?? 0) > 0).length;
  const setValue = cards.reduce((n, c) => n + (marketPrice(c) ?? 0), 0);

  const quickAdd = (c: Card) => {
    addOwned({ card: c, qty: 1, cost: 0, graded: false, condition: 'Near Mint' });
    setNotice(`Added ${c.name}. Open My cards to set what you paid.`);
  };
  const addSealedItem = (p: SealedItem) => {
    addSealed({ productId: p.id, name: p.name, setName: p.setName ?? set.name, type: p.type, qty: 1, cost: 0, market: p.market, updatedAt: p.updatedAt });
    setNotice(`Added ${p.name}. Open My cards to set what you paid.`);
  };
  const sealedCount = (p: SealedItem) =>
    sealed.filter((s) => (p.id != null && s.productId === p.id) || (p.id == null && s.name === p.name)).reduce((n, s) => n + s.qty, 0);

  return (
    <Screen>
      <PageHead eyebrow={`${set.series} · ${formatDate(set.releaseDate)}`} title={set.name} text={`${set.total} cards in the set.`} />
      {set.images?.logo ? <Image source={{ uri: set.images.logo }} style={{ height: 70 }} resizeMode="contain" /> : null}
      <Segmented options={['Singles', 'Sealed']} value={tab} onChange={setTab} />
      {notice ? <Text style={{ color: colors.amber }}>{notice}</Text> : null}

      {tab === 'Singles' ? (
        <>
          {!busy && cards.length ? (
            <Panel style={{ gap: 4 }}>
              <Text style={{ color: colors.text, fontSize: 18, fontWeight: '700' }}>
                You own {ownedDistinct} of {cards.length}
              </Text>
              <Text style={{ color: colors.muted }}>One of each card at stored market prices: {formatMoney(setValue)}</Text>
            </Panel>
          ) : null}
          <SearchBox value={q} onChangeText={setQ} placeholder="Search this set" />
          <Segmented options={['All', 'Owned', 'Missing']} value={seg} onChange={setSeg} />
          <Select value={rarity} options={rarities} onChange={setRarity} />
          {busy ? <Loading /> : null}
          {error ? <Text style={{ color: colors.red }}>{error}</Text> : null}
          <Panel>
            {!busy && shown.length === 0 ? (
              <Empty icon="albums-outline" text="No cards match." />
            ) : (
              shown.map((c) => (
                <CardRow
                  key={c.id}
                  card={c}
                  onPress={() => nav.navigate('CardDetail', { card: c })}
                  right={<AddButton count={count.get(c.id) ?? 0} onPress={() => quickAdd(c)} />}
                />
              ))
            )}
          </Panel>
        </>
      ) : (
        <>
          {sBusy ? <Loading /> : null}
          {sError ? <Text style={{ color: colors.red, lineHeight: 22 }}>{sError}</Text> : null}
          <Panel style={{ gap: 14 }}>
            {!sBusy && items && items.length === 0 ? (
              <Empty icon="cube-outline" text="No sealed products found for this set. Try the Sealed products page and search by name." />
            ) : null}
            {(items ?? []).map((p, i) => (
              <View
                key={`${p.id ?? p.name}-${i}`}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: colors.border }}
              >
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={{ color: colors.text, fontSize: 16 }}>{p.name}</Text>
                  <Text style={{ color: colors.muted, fontSize: 13 }}>
                    {[p.type, p.updatedAt ? `updated ${formatDate(p.updatedAt)}` : null].filter(Boolean).join(' · ')}
                  </Text>
                  <Text style={{ color: colors.text, fontWeight: '700' }}>
                    Market {formatMoney(p.market)}
                    {p.low != null ? ` · Low ${formatMoney(p.low)}` : ''}
                  </Text>
                </View>
                <AddButton count={sealedCount(p)} onPress={() => addSealedItem(p)} />
              </View>
            ))}
          </Panel>
        </>
      )}
    </Screen>
  );
}
