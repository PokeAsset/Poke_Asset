import React from 'react';
import { Text, View } from 'react-native';
import { colors, mono } from './theme';
import { formatMoney } from './api';
import { Snapshot } from './types';

/**
 * Portfolio value over time. Only real, recorded readings are drawn: one per
 * day the app refreshed prices. No back-filled or invented history.
 */
export function ValueChart({ snapshots }: { snapshots: Snapshot[] }) {
  const pts = snapshots.slice(-30);
  if (pts.length < 2) {
    return (
      <Text style={{ color: colors.muted, fontSize: 15, lineHeight: 22 }}>
        History builds up as you open the app on different days. Today's value is saved; come back
        tomorrow to see the first change.
      </Text>
    );
  }
  const max = Math.max(...pts.map((p) => p.value), 1);
  const first = pts[0];
  const last = pts[pts.length - 1];
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, gap: 3 }}>
        {pts.map((p) => (
          <View
            key={p.date}
            style={{
              flex: 1,
              height: Math.max(4, (p.value / max) * 120),
              backgroundColor: p.value >= first.value ? colors.amber : colors.red,
              borderRadius: 3,
            }}
          />
        ))}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {first.date} · {formatMoney(first.value)}
        </Text>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {last.date} · {formatMoney(last.value)}
        </Text>
      </View>
    </View>
  );
}

/* ---------- price history line chart (raw vs graded) ---------- */

export type LineSeries = { label: string; points: { date: string; price: number }[] };

/** Line chart drawn from real readings only. Shows an honest message when there is not enough data. */
export function PriceChart({ series, note }: { series: LineSeries[]; note?: string }) {
  const usable = series.filter((s) => s.points.length >= 2);
  const [pick, setPick] = React.useState(0);
  const [w, setW] = React.useState(0);
  if (usable.length === 0) {
    return (
      <Text style={{ color: colors.muted, fontSize: 15, lineHeight: 22 }}>
        {note ??
          'No price history yet. Each time you refresh this card’s price, a point is saved on this device, so the graph grows over time.'}
      </Text>
    );
  }
  const cur = usable[Math.min(pick, usable.length - 1)];
  const pts = cur.points.slice(-120);
  const prices = pts.map((p) => p.price);
  const lo = Math.min(...prices);
  const hi = Math.max(...prices);
  const H = 150;
  const span = hi - lo || 1;
  const xy = pts.map((p, i) => ({
    x: pts.length === 1 ? 0 : (i / (pts.length - 1)) * Math.max(w - 8, 1) + 4,
    y: H - 8 - ((p.price - lo) / span) * (H - 16),
  }));
  const first = pts[0];
  const last = pts[pts.length - 1];
  const change = first.price > 0 ? ((last.price - first.price) / first.price) * 100 : null;
  const line = last.price >= first.price ? colors.amber : colors.red;
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {usable.map((s, i) => (
          <Text
            key={s.label}
            onPress={() => setPick(i)}
            style={{
              color: i === pick ? colors.gold : colors.muted,
              borderColor: i === pick ? colors.tintGoldBorder : colors.border,
              backgroundColor: i === pick ? colors.tintGold : 'transparent',
              borderWidth: 1,
              borderRadius: 999,
              paddingHorizontal: 12,
              paddingVertical: 6,
              fontWeight: '600',
              overflow: 'hidden',
            }}
          >
            {s.label}
          </Text>
        ))}
      </View>
      <View style={{ height: H }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
        {w > 0
          ? xy.slice(1).map((b, i) => {
              const a = xy[i];
              const len = Math.hypot(b.x - a.x, b.y - a.y);
              const ang = Math.atan2(b.y - a.y, b.x - a.x);
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    left: (a.x + b.x) / 2 - len / 2,
                    top: (a.y + b.y) / 2 - 1,
                    width: len,
                    height: 2,
                    backgroundColor: line,
                    transform: [{ rotate: `${ang}rad` }],
                  }}
                />
              );
            })
          : null}
        {w > 0 ? (
          <View
            style={{
              position: 'absolute',
              left: xy[xy.length - 1].x - 4,
              top: xy[xy.length - 1].y - 4,
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: line,
            }}
          />
        ) : null}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {first.date} · {formatMoney(first.price)}
        </Text>
        <Text style={{ color: colors.muted, fontFamily: mono, fontSize: 12 }}>
          {last.date} · {formatMoney(last.price)}
        </Text>
      </View>
      <Text style={{ color: colors.muted, fontSize: 13 }}>
        Low {formatMoney(lo)} · High {formatMoney(hi)}
        {change != null ? ` · ${change >= 0 ? '+' : ''}${change.toFixed(1)}% over this range` : ''}
      </Text>
    </View>
  );
}
