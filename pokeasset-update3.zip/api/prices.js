const { limited, send } = require('./_util');

const BASE = 'https://www.pokemonpricetracker.com/api/v2';

/* ---- tolerant readers: the upstream response shape is only partly documented ---- */

const num = (v) => (typeof v === 'number' && isFinite(v) ? v : typeof v === 'string' && v.trim() !== '' && isFinite(Number(v)) ? Number(v) : null);

function pickPrice(o) {
  if (!o || typeof o !== 'object') return num(o);
  for (const k of ['smartMarketPrice', 'avg', 'average', 'averagePrice', 'median', 'medianPrice', 'marketPrice', 'market', 'price']) {
    const v = num(o[k]);
    if (v != null) return v;
  }
  return null;
}

/** Finds graded prices like { psa10: {avg: 450} } or { salesByGrade: { psa10: {...} } } anywhere inside ebay. */
function readGraded(ebay) {
  const out = {};
  const seen = new Set();
  const walk = (o, depth) => {
    if (!o || typeof o !== 'object' || depth > 4 || seen.has(o)) return;
    seen.add(o);
    for (const [k, v] of Object.entries(o)) {
      const m = /^(psa|cgc|bgs|sgc)[\s_-]?(\d+(?:\.\d+)?)$/i.exec(k);
      if (m) {
        const price = pickPrice(v);
        if (price != null) {
          out[`${m[1].toUpperCase()} ${m[2]}`] = {
            price,
            sales: v && typeof v === 'object' ? num(v.count ?? v.salesCount ?? v.sales) : null,
          };
        }
      } else if (v && typeof v === 'object') {
        walk(v, depth + 1);
      }
    }
  };
  walk(ebay, 0);
  return out;
}

const dateOf = (o) => o && (o.date || o.day || o.timestamp || o.t || o.createdAt);
const priceOf = (o) => num(o && (o.market ?? o.price ?? o.marketPrice ?? o.avg ?? o.average ?? o.value));

function findSeries(o, depth = 0) {
  if (!o || typeof o !== 'object' || depth > 5) return null;
  if (Array.isArray(o)) {
    const pts = o
      .map((p) => ({ date: dateOf(p), price: priceOf(p) }))
      .filter((p) => p.date && p.price != null)
      .map((p) => ({ date: String(p.date).slice(0, 10), price: p.price }));
    if (pts.length >= 2) return pts;
    return null;
  }
  for (const v of Object.values(o)) {
    const s = findSeries(v, depth + 1);
    if (s) return s;
  }
  return null;
}

function normalizeCard(c) {
  const graded = readGraded(c.ebay);
  const gradedHistory = {};
  const ph = c.priceHistory || {};
  if (ph && typeof ph === 'object' && !Array.isArray(ph)) {
    for (const [k, v] of Object.entries(ph)) {
      if (/^(psa|cgc|bgs|sgc)/i.test(k)) {
        const s = findSeries(v);
        if (s) gradedHistory[k.toUpperCase()] = s;
      }
    }
  }
  return {
    name: c.name,
    setName: c.setName || (c.set && c.set.name) || null,
    number: c.cardNumber || c.number || null,
    tcgPlayerId: c.tcgPlayerId || c.tcgplayerId || null,
    market: num(c.prices && (c.prices.market ?? c.prices.marketPrice)) ?? num(c.marketPrice),
    low: num(c.prices && (c.prices.low ?? c.prices.lowPrice)) ?? num(c.lowPrice),
    graded,
    history: { raw: findSeries(ph.variants || ph.raw || ph) || null, graded: gradedHistory },
    updatedAt: c.lastUpdated || c.updatedAt || (c.prices && c.prices.lastUpdated) || null,
  };
}

const listOf = (j) => (Array.isArray(j) ? j : Array.isArray(j && j.data) ? j.data : j && j.data ? [j.data] : []);

module.exports = async (req, res) => {
  if (req.method !== 'GET') return send(res, 405, { error: 'GET only' });
  if (limited(req, 40)) return send(res, 429, { error: 'Too many requests. Wait a minute and try again.' });
  const key = process.env.PRICE_API_KEY;
  if (!key) {
    return send(res, 503, {
      error: 'PRICE_API_KEY is not set on the server, so graded prices, history and sealed products are off.',
      notConfigured: true,
    });
  }
  const q = req.query || {};
  const action = q.action;
  const headers = { Authorization: `Bearer ${key}` };
  const call = async (path, params) => {
    const url = `${BASE}/${path}?${new URLSearchParams(params).toString()}`;
    const r = await fetch(url, { headers });
    const text = await r.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      json = { raw: text.slice(0, 500) };
    }
    if (!r.ok) {
      const e = new Error((json && (json.error || json.message)) || `Price service error (${r.status})`);
      e.status = r.status;
      throw e;
    }
    return json;
  };
  try {
    if (action === 'card') {
      const params = { limit: '5', includeEbay: 'true', includeHistory: 'true', days: String(q.days || 90) };
      if (q.tcgPlayerId) params.tcgPlayerId = String(q.tcgPlayerId);
      else {
        if (!q.name) return send(res, 400, { error: 'name is required' });
        params.search = [q.name, q.number].filter(Boolean).join(' ');
        if (q.set) params.set = String(q.set);
      }
      const json = await call('cards', params);
      if (q.debug === '1') return send(res, 200, { debug: json });
      const cards = listOf(json).map(normalizeCard);
      return send(res, 200, { ok: true, cards });
    }
    if (action === 'sealed') {
      const params = { search: String(q.q || '') };
      if (q.set) params.set = String(q.set);
      if (!params.search && !params.set) return send(res, 400, { error: 'Type a product name or choose a set.' });
      const json = await call('sealed-products', params);
      if (q.debug === '1') return send(res, 200, { debug: json });
      const items = listOf(json).map((p) => ({
        id: p.tcgPlayerId || p.id || null,
        name: p.name,
        setName: p.setName || (p.set && p.set.name) || null,
        type: p.productType || p.type || null,
        market: num(p.marketPrice ?? (p.prices && p.prices.market)),
        low: num(p.lowPrice ?? (p.prices && p.prices.low)),
        updatedAt: p.lastPriceUpdate || p.updatedAt || null,
        history: findSeries(p.priceHistory) || null,
      }));
      return send(res, 200, { ok: true, items });
    }
    return send(res, 400, { error: 'Unknown action.' });
  } catch (e) {
    return send(res, e.status === 401 || e.status === 403 ? 401 : 502, { error: e.message || 'Price request failed.' });
  }
};
