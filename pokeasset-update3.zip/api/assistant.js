const { limited, send, readBody, gemini } = require('./_util');

const SYSTEM =
  'You are the PokéAsset financial assistant for a Pokémon card collector. You can analyse the user\'s portfolio, ' +
  'explain ROI and cost basis, compare singles with sealed product, review recorded sales and expenses, and discuss ' +
  'whether to hold or sell. ' +
  'Rules: never invent a price, sale, population number or date. Only quote numbers that appear in the PORTFOLIO CONTEXT. ' +
  'Every stored price has a date; mention it when it matters and say when it looks old. ' +
  'If a number is missing, say so and say where to check (TCGplayer, eBay sold listings, PSA). ' +
  'Distinguish an estimate, an asking price and a sold price. For hold/sell questions, give the factors (cost basis, ' +
  'concentration, liquidity, fees, taxes, price trend if known) and a reasoned view, but say you are not a licensed ' +
  'financial advisor and the decision is theirs. If the user asks about expenses and none are recorded, explain that the ' +
  'app tracks cost basis and recorded sales only. ' +
  'Keep answers short and practical. Use plain text, no markdown tables.';

module.exports = async (req, res) => {
  if (req.method !== 'POST') return send(res, 405, { error: 'POST only' });
  if (limited(req, 20)) return send(res, 429, { error: 'Too many requests. Wait a minute and try again.' });
  const body = await readBody(req);
  const msgs = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  const context = typeof body.context === 'string' ? body.context.slice(0, 9000) : '';
  if (msgs.length === 0) return send(res, 400, { error: 'No message.' });
  const transcript = msgs
    .map((m) => `${m.role === 'assistant' ? 'Assistant' : 'User'}: ${String(m.text || '').slice(0, 2000)}`)
    .join('\n');
  try {
    const text = await gemini({
      system: `${SYSTEM}\n\nPORTFOLIO CONTEXT (from the user's app, may be empty):\n${context || '(none)'}`,
      parts: [{ text: `CONVERSATION:\n${transcript}\n\nAssistant:` }],
    });
    return send(res, 200, { ok: true, text });
  } catch (e) {
    if (e.code === 'not_configured') return send(res, 503, { error: e.message, notConfigured: true });
    return send(res, 502, { error: e.message || 'Assistant request failed.' });
  }
};
